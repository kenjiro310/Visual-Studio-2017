/* 
 John H Rucker 
 CSC 4820
 
 Project 4
 
 Loading, displaying, and texturing a 3d model
 I changed the mtl PATH to reflect for the models to refelect the home directory to access images
 "garden.jpg" must be in the working directory
 "desert.jpg" must be in the working directory
 "shape_BW.png" must be in the working directory
*/
